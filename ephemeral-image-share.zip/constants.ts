
export const MAX_FILES_UPLOAD = 33;
export const EXPIRY_DURATION_HOURS = 72;
export const EXPIRY_DURATION_MS = EXPIRY_DURATION_HOURS * 60 * 60 * 1000;
export const LOCAL_STORAGE_KEY = 'ephemeralImageBatches';
